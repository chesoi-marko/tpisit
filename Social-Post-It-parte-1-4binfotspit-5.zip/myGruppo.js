function AddElementToJSON(jsondata, elemento) {
  jsondata.push(elemento);
}

module.exports = { AddElementToJSON }